<?php
declare(strict_types=1);
$root = __DIR__ . '/_cmcb';
// Shared hosting: reject missing or modified protection files.
foreach ([__DIR__ . '/.htaccess' => '5d6a908e221a803483dff8c6cbd8a1204f5404d66beec6c21966f5d3611ca143', $root . '/.htaccess' => 'dbdf47f62a27badc00789cd9369768de4d210117e6b04d534677154701c19435'] as $guard => $expected) {
    $actual = is_file($guard) ? @hash_file('sha256', $guard) : false;
    if (!is_string($actual) || !hash_equals($expected, $actual)) {
        http_response_code(503); header('Content-Type: text/plain; charset=utf-8');
        exit('Protection du dossier privé manquante ou modifiée. Consultez le guide avant installation.');
    }
}

require $root . '/src/Config.php';
require $root . '/src/Http.php';
require $root . '/src/Database.php';
require $root . '/src/Content.php';
require $root . '/src/Design.php';
require $root . '/src/View.php';
require $root . '/src/Validation.php';
require $root . '/src/Media.php';
require $root . '/src/Auth.php';
require $root . '/src/Repository.php';
require $root . '/src/RateLimiter.php';
require $root . '/src/Mailer.php';
require $root . '/src/App.php';
ini_set('display_errors', '0');
date_default_timezone_set('Africa/Tunis');
try {
    $config = new CMCB\Config($root);
    $request = CMCB\Request::capture($config);
    (new CMCB\App($config))->handle($request)->send();
} catch (CMCB\HttpError $e) {
    http_response_code($e->status); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
    echo json_encode(['error' => ['code' => $e->errorCode, 'message' => $e->getMessage()]], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('CMCB bootstrap: ' . get_class($e) . ': ' . $e->getMessage());
    http_response_code(500); header('Content-Type: application/json; charset=utf-8');
    echo '{"error":{"code":"BOOTSTRAP_ERROR","message":"Configuration serveur incomplète. Consultez les journaux privés."}}';
}
